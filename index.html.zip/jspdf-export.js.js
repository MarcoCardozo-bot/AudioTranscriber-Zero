function pdfExport(notes){
  alert('PDF:Em construção. Use o MIDI por enquanto.');
}
